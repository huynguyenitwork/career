using CiberMVC.Models;
using CiberMVC.Models.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CiberMVC.Data.Config;

public class ProductConfiguration:IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> builder)
    {
        builder.HasKey(p => p.Id);
        builder.Property(p => p.Id).ValueGeneratedOnAdd();
        builder.Property(p => p.Name).IsRequired();
        builder.Property(p => p.Price).IsRequired();
        builder.Property(p => p.Quantity).IsRequired();
        builder.HasOne(p => p.Category)
            .WithMany(c=>c.Products)
            .OnDelete(DeleteBehavior.Restrict);
    }
}