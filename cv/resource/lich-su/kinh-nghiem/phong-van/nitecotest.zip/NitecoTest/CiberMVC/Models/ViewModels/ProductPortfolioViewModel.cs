using CiberMVC.Data;
using CiberMVC.Models.Entity;
using CiberMVC.Models.ViewModels.Utilities;
using Microsoft.EntityFrameworkCore;

namespace CiberMVC.Models.ViewModels;

public class ProductPortfolioViewModel: PortfolioViewModel<Product>
{
    public ProductPortfolioViewModel(ApplicationDbContext dbContext)
    {
        var products =  dbContext.Products.AsNoTracking().ToList();
        products.ForEach(f => { ComboBoxOptions.AddOption(f.Id.ToString(), f.Name); });
    }
}