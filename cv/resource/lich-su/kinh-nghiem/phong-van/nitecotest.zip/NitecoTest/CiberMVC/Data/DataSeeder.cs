using CiberMVC.Models.Entity;
using Microsoft.EntityFrameworkCore;

namespace CiberMVC.Data;

public class DataSource
{
    public List<Category> Categories { get; private set; }
    public List<Product> Products { get; private set;}
    public List<Customer> Customers { get; private set;}
    public List<Order> Orders { get; private set;}

    public static DataSource Build(List<Category> categories, List<Product> products, List<Customer> customers,
        List<Order> orders)
    {
        return new DataSource(categories, products, customers, orders);
    }
    private DataSource(List<Category> categories, List<Product> products, List<Customer> customers, List<Order> orders)
    {
        Categories = categories;
        Products = products;
        Customers = customers;
        Orders = orders;
    }
}
public static class DataSeeder
{

    public static DataSource LoadData()
    {
        var categories = new List<Category>
        {
            new Category {Id=1, Name = "Electronics" },
            new Category {Id=2, Name = "Clothing" },
            new Category {Id=3, Name = "Books" },
            new Category {Id=4, Name = "Home & Garden" },
            new Category {Id=5, Name = "Sports & Outdoors" },
            new Category {Id=6, Name = "Toys & Games" },
            new Category {Id=7, Name = "Beauty & Personal Care" },
            new Category {Id=8, Name = "Automotive" },
            new Category {Id=9, Name = "Health & Household" },
            new Category {Id=10, Name = "Office Products" }
        };
         var products = new List<Product>
        {
            new Product {Id=1, Name = "iPhone 12 Pro", Price = 999, Quantity = 100, CategoryId = 1 },
            new Product {Id=2, Name = "Samsung Galaxy S21", Price = 799, Quantity = 50, CategoryId = 1 },
            new Product {Id=3, Name = "Nike Air Max 270", Price = 150, Quantity = 2, CategoryId = 2 },
            new Product {Id=4, Name = "Adidas Superstar", Price = 80, Quantity = 1, CategoryId = 2 },
            new Product {Id=5, Name = "The Great Gatsby", Price = 10, Quantity = 100, CategoryId = 3 },
            new Product {Id=6, Name = "To Kill a Mockingbird", Price = 12, Quantity = 100, CategoryId = 3 },
            new Product {Id=7, Name = "Lawn Mower", Price = 250, Quantity = 100, CategoryId = 4 },
            new Product {Id=8, Name = "Outdoor Patio Set", Price = 500, Quantity = 60, CategoryId = 4 },
            new Product {Id=9, Name = "Yoga Mat", Price = 30, Quantity = 100, CategoryId = 5 },
            new Product {Id=10, Name = "Basketball", Price = 25, Quantity = 100, CategoryId = 5 },
            new Product {Id=11, Name = "LEGO Classic Bricks", Price = 30, Quantity = 100, CategoryId = 6 },
            new Product {Id=12, Name = "Monopoly Board Game", Price = 20, Quantity = 100, CategoryId = 6 },
            new Product {Id=13, Name = "L'Oreal Paris Shampoo", Price = 10, Quantity = 100, CategoryId = 7 },
            new Product {Id=14, Name = "Dove Body Wash", Price = 8, Quantity = 100, CategoryId = 7 },
            new Product {Id=15, Name = "Car Battery", Price = 100, Quantity = 100, CategoryId = 8 },
            new Product {Id=16, Name = "Motor Oil", Price = 20, Quantity = 100, CategoryId = 8 },
            new Product {Id=17, Name = "Multivitamin", Price = 15, Quantity = 100, CategoryId = 9 },
            new Product {Id=18, Name = "Hand Sanitizer", Price = 5, Quantity = 100, CategoryId = 9 },
            new Product {Id=19, Name = "Ballpoint Pens", Price = 5, Quantity = 100, CategoryId = 10 },
            new Product {Id=20, Name = "Printer Paper", Price = 10, Quantity = 100, CategoryId = 10 }
        };
         var customers = new List<Customer>
         {
             new Customer {Id=1, Name = "John Smith", Email = "john.smith@example.com", Address = "1600 Pennsylvania Ave NW, Washington, DC 20500" },
             new Customer {Id=2, Name = "Jane Doe", Email = "jane.doe@example.com", Address = "350 5th Ave, New York, NY 10118" },
             new Customer {Id=3, Name = "Bob Johnson", Email = "bob.johnson@example.com", Address = "600 W Chicago Ave, Chicago, IL 60654" },
             new Customer {Id=4, Name = "Emily Davis", Email = "emily.davis@example.com", Address = "1 Microsoft Way, Redmond, WA 98052" },
             new Customer {Id=5, Name = "Michael Brown", Email = "michael.brown@example.com", Address = "1600 Amphitheatre Pkwy, Mountain View, CA 94043" },
             new Customer {Id=6, Name = "Samantha Lee", Email = "samantha.lee@example.com", Address = "221B Baker St, London NW1 6XE, United Kingdom" },
             new Customer {Id=7, Name = "David Kim", Email = "david.kim@example.com", Address = "1600 Vine St, Los Angeles, CA 90028" },
             new Customer {Id=8, Name = "Karen Chen", Email = "karen.chen@example.com", Address = "116th St & Broadway, New York, NY 10027" },
             new Customer {Id=9, Name = "Daniel Martinez", Email = "daniel.martinez@example.com", Address = "1600 Vine St, Los Angeles, CA 90028" },
             new Customer {Id=10, Name = "Olivia Wilson", Email = "olivia.wilson@example.com", Address = "1600 Vine St, Los Angeles, CA 90028" }
         };
         var orders = new List<Order>
         {
             new Order {Id=1, OrderName = "5 iPhone 12 Pros for office use", CustomerId = 1, ProductId = 1, Amount = 2, OrderDate = DateTime.Parse("2022-12-02") },
             new Order {Id=2, OrderName = "2 Samsung Galaxy S21 phones for personal use", CustomerId = 2, ProductId = 2, Amount = 1, OrderDate = DateTime.Parse("2022-12-02") },
             new Order {Id=3, OrderName = "2 pairs of Nike Air Max 270 shoes for gym", CustomerId = 3, ProductId = 3, Amount = 1, OrderDate = DateTime.Parse("2022-12-03") },
             new Order {Id=4, OrderName = "1 pair of Adidas Superstar shoes for casual wear", CustomerId = 4, ProductId = 4, Amount = 2, OrderDate = DateTime.Parse("2022-12-03") },
             new Order {Id=5,  OrderName="10 copies of The Great Gatsby for high school literature class", CustomerId = 5, ProductId = 5, Amount = 1, OrderDate = DateTime.Parse("2022-12-03") },
             new Order {Id=6, OrderName = "10 copies of To Kill a Mockingbird for book club", CustomerId = 6, ProductId = 6, Amount = 1, OrderDate = DateTime.Parse("2022-12-05") },
             new Order {Id=7, OrderName = "1 Lawn Mower for yard maintenance" , CustomerId = 7, ProductId = 7, Amount = 1, OrderDate = DateTime.Parse("2022-12-05") },
             new Order {Id=8, OrderName = "1 Outdoor Patio Set for summer parties" , CustomerId = 8, ProductId = 8, Amount = 1, OrderDate = DateTime.Parse("2022-12-06") },
             new Order {Id=9, OrderName = "2 Yoga Mats for home workouts" , CustomerId = 9, ProductId = 9, Amount = 1, OrderDate = DateTime.Parse("2022-12-06") },
             new Order {Id=10, OrderName = "1 Basketball for outdoor games", CustomerId = 10, ProductId = 10, Amount = 1, OrderDate = DateTime.Parse("2022-12-06") },
         };
         return DataSource.Build(categories, products, customers, orders);
    }
    
    
    public static void SeedData(this ModelBuilder modelBuilder)
    {
        var dataSource = LoadData();
        modelBuilder.Entity<Category>().HasData(dataSource.Categories);
        modelBuilder.Entity<Product>().HasData(dataSource.Products);
        modelBuilder.Entity<Customer>().HasData(dataSource.Customers);
        modelBuilder.Entity<Order>().HasData(dataSource.Orders);
    }
    
    public static void SeedData(this ApplicationDbContext dbContext)
    {
        var dataSource = LoadData();
        dbContext.Categories.AddRange(dataSource.Categories);
        dbContext.Products.AddRange(dataSource.Products);
        dbContext.Customers.AddRange(dataSource.Customers);
        dbContext.Orders.AddRange(dataSource.Orders);
        dbContext.SaveChanges();
    }
}