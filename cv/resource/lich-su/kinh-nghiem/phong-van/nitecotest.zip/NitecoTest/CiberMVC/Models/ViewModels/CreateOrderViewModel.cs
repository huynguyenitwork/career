namespace CiberMVC.Models.ViewModels;

public class CreateOrderViewModel
{
    public string? OrderName { get; set; }
    public int Amount { get; set; }
    public DateTime OrderDate { get; set; }
    public int CustomerId { get; set; }
    public int ProductId { get; set; }
}