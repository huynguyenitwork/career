using CiberMVC.Models;
using CiberMVC.Models.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CiberMVC.Data.Config;

public class OrderConfiguration:IEntityTypeConfiguration<Order>
{
    public void Configure(EntityTypeBuilder<Order> builder)
    {
        builder.HasKey(p => p.Id);
        builder.Property(p => p.Id).ValueGeneratedOnAdd();
        builder.Property(p => p.Amount).IsRequired();
        builder.Property(p => p.OrderDate).IsRequired();
        builder.HasOne(p => p.Customer)
            .WithMany(c => c.Orders)
            .OnDelete(DeleteBehavior.Restrict);
        builder.HasOne(p => p.Product)
            .WithMany(c=>c.Orders)
            .OnDelete(DeleteBehavior.Restrict);
    }
}