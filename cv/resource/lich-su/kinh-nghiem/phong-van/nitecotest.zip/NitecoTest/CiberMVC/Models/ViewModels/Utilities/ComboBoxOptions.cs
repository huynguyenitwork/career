using Microsoft.AspNetCore.Mvc.Rendering;

namespace CiberMVC.Models.ViewModels.Utilities;

public class ComboBoxOptions<T>
{
    public List<SelectListItem> Options { get; set; }

    public ComboBoxOptions()
    {
        Options = new List<SelectListItem>();
    }

    public void AddOption(string value, string text)
    {
        Options.Add(new SelectListItem { Value = value, Text = text });
    }
}