namespace CiberMVC.Models.ViewModels;

public class PagedViewModel<T>
{
    public IEnumerable<T> Items { get; set; }
    public int PageNumber { get; set; }
    public int PageSize { get; set; }
    public int TotalItems { get; set; }
    public string? Search { get; set; }
}