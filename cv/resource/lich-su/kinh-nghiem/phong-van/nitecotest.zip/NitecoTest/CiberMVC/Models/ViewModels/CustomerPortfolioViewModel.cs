using CiberMVC.Data;
using CiberMVC.Models.Entity;
using CiberMVC.Models.ViewModels.Utilities;
using Microsoft.EntityFrameworkCore;

namespace CiberMVC.Models.ViewModels;

public class CustomerPortfolioViewModel : PortfolioViewModel<Customer>
{
    public CustomerPortfolioViewModel(ApplicationDbContext dbContext)
    {
        var customers =  dbContext.Customers.AsNoTracking().ToList();
        customers.ForEach(f => { ComboBoxOptions.AddOption(f.Id.ToString(), f.Name); });
    }
}