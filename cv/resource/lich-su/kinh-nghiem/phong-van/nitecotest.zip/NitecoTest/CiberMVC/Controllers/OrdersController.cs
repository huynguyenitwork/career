using CiberMVC.Data;
using CiberMVC.Models.Entity;
using CiberMVC.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CiberMVC.Controllers;

public class OrdersController : Controller
{
    private readonly ApplicationDbContext _applicationDbContext;
    private readonly ILogger<OrdersController> _logger;
    private const int PageSize = 5;

    public OrdersController(ApplicationDbContext applicationDbContext, ILogger<OrdersController> logger)
    {
        _applicationDbContext = applicationDbContext;
        _logger = logger;
    }

    [HttpGet]
    public async Task<IActionResult> Index(int? page)
    {
        try
        {
            var pageNumber = page ?? 1;

            var orders = _applicationDbContext.Orders
                .Include(o => o.Product)
                .Include(o => o.Product.Category)
                .Include(o => o.Customer)
                .AsNoTracking();

            var totalItems = await orders.CountAsync();

            if (totalItems == 0)
            {
                string message = "Không có đơn đặt hàng có sẵn.";
                ViewBag.Message = message;
                _logger.LogWarning(message);
                return View();
            }

            var pagedOrders = await orders.OrderBy(o => o.Product.Category).Skip((pageNumber - 1) * PageSize)
                .Take(PageSize)
                .ToListAsync();

            var viewModel = new PagedViewModel<Order>
            {
                Items = pagedOrders,
                PageNumber = pageNumber,
                PageSize = PageSize,
                TotalItems = await orders.CountAsync()
            };

            return View(viewModel);
        }
        catch (Exception ex)
        {
            // Ghi log lỗi chi tiết
            _logger.LogError(ex, "Đã xảy ra lỗi.");
            return View();
        }
    }

    [HttpGet]
    public async Task<IActionResult> Get(string search, int? page)
    {
        try
        {
            var pageNumber = page ?? 1;

            var orders = _applicationDbContext.Orders
                .Include(o => o.Product)
                .Include(o => o.Product.Category)
                .Include(o => o.Customer)
                .AsNoTracking();
            if (!string.IsNullOrEmpty(search))
            {
                orders = orders.Where(o => o.Product.Name.ToLower().Contains(search.ToLower()));
            }

            var totalItems = await orders.CountAsync();

            if (totalItems == 0)
            {
                string message = "There are no orders available.";
                ViewBag.Message = message;
                _logger.LogWarning(message);
                return View("Index");
            }

            var pagedOrders = await orders.OrderBy(o => o.Product.Category).Skip((pageNumber - 1) * PageSize)
                .Take(PageSize)
                .ToListAsync();

            var viewModel = new PagedViewModel<Order>
            {
                Items = pagedOrders,
                PageNumber = pageNumber,
                PageSize = PageSize,
                TotalItems = await orders.CountAsync(),
                Search = search
            };

            return View("Index", viewModel);
        }
        catch (Exception ex)
        {
            // Ghi log lỗi chi tiết
            _logger.LogError(ex, "Đã xảy ra lỗi.");
            return View("Index");
        }
    }

    [HttpGet]
    public IActionResult Create()
    {
        var productPortfolio = new ProductPortfolioViewModel(_applicationDbContext);
        var customerPortfolio = new CustomerPortfolioViewModel(_applicationDbContext);
        ViewBag.Products = productPortfolio.ComboBoxOptions.Options;
        ViewBag.Customers = customerPortfolio.ComboBoxOptions.Options;
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateOrderViewModel createOrderRequest)
    {
        try
        {
            void LoadDataSource()
            {
                var productPortfolio = new ProductPortfolioViewModel(_applicationDbContext);
                var customerPortfolio = new CustomerPortfolioViewModel(_applicationDbContext);
                ViewBag.Products = productPortfolio.ComboBoxOptions.Options;
                ViewBag.Customers = customerPortfolio.ComboBoxOptions.Options;
            }

            if (ModelState.IsValid)
            {
                var product = await _applicationDbContext.Products.FindAsync(createOrderRequest.ProductId);
                if (product is null) return RedirectToAction("Create");
                if (createOrderRequest.Amount > product.Quantity)
                {
                    var message = "Số lượng sản phẩm không đủ cho đơn đặt hàng này.";
                    ViewBag.ErrorMessage = message;
                    _logger.LogWarning(message);
                    LoadDataSource();
                    return View("Create", createOrderRequest);
                }

                var order = new Order()
                {
                    Amount = createOrderRequest.Amount,
                    CustomerId = createOrderRequest.CustomerId,
                    OrderDate = createOrderRequest.OrderDate,
                    OrderName = createOrderRequest.OrderName,
                    ProductId = createOrderRequest.ProductId
                };
                await _applicationDbContext.Orders.AddAsync(order);
                await _applicationDbContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            LoadDataSource();
            return View(createOrderRequest);
        }
        catch (Exception ex)
        {
            // Ghi log lỗi chi tiết
            _logger.LogError(ex, "Đã xảy ra lỗi.");
            return View(createOrderRequest);
        }
    }
}