namespace CiberMVC.Models.ViewModels.Utilities;

public class PortfolioViewModel<T> where T : class
{
    public ComboBoxOptions<T> ComboBoxOptions { get; set; }

    public PortfolioViewModel()
    {
        ComboBoxOptions = new ComboBoxOptions<T>();
    }
}