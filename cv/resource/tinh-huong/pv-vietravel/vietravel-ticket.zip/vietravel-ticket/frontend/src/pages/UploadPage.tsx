import React, { useState } from "react";
type Passenger = {
  firstName: string;
  lastName: string;
  fullName: string;
  flightCodes: string[];
};

type Flight = {
  flightCode: string;
  date?: string;
  ticketClass?: string;
  departure?: string;
  arrival?: string;
};

type TicketDto = {
  bookingCode: string;
  bookingDate?: string;
  email?: string;
  contact?: string;
  passengers: Passenger[];
  flights: Flight[];
};


export default function UploadPage() {
  const [file, setFile] = useState<File | null>(null);
  const [ticket, setTicket] = useState<TicketDto | null>(null);

  const handleChooseFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFile(e.target.files[0]);
      setTicket(null); // reset kết quả cũ
    }
  };

  const handleAnalyze = async () => {
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    const resp = await fetch(`${process.env.REACT_APP_API_URL}/api/upload`, {
      method: "POST",
      body: formData,
    });

    if (resp.ok) {
      const data: TicketDto = await resp.json();
      setTicket(data);
    }
  };

  return (
    <div style={{ margin: "16px" }}>
      <input type="file" accept=".docx" onChange={handleChooseFile} />
      <button
        onClick={handleAnalyze}
        disabled={!file}
        style={{
          marginLeft: "8px",
          border: "1px solid #333",
          background: file ? "#1976d2" : "#aaa",
          color: "#fff",
          cursor: file ? "pointer" : "not-allowed",
        }}
      >
        Phân tích
      </button>

      {ticket && (
        <div style={{ marginTop: "16px" }}>
          <h2 style={{ fontWeight: "bold", marginBottom: "8px" }}>Kết quả</h2>
          <table style={{ borderCollapse: "collapse", width: "100%" }}>
            <thead>
              <tr>
                <th style={{ border: "1px solid #333", fontWeight: "bold" }}>Họ</th>
                <th style={{ border: "1px solid #333", fontWeight: "bold" }}>Tên</th>
                <th style={{ border: "1px solid #333", fontWeight: "bold" }}>Code vé booking</th>
              </tr>
            </thead>
            <tbody>
              {ticket.passengers.map((p, idx) => (
                <tr key={idx}>
                  <td style={{ border: "1px solid #333" }}>{p.firstName}</td>
                  <td style={{ border: "1px solid #333" }}>{p.lastName}</td>
                  <td style={{ border: "1px solid #333" }}>{ticket.bookingCode}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
