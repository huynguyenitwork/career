import UploadPage from "./pages/UploadPage";

function App() {
  return (
    <div>
      <h1 style={{ margin: "16px" }}>Upload vé VietJet</h1>
      <UploadPage />
    </div>
  );
}
export default App;
