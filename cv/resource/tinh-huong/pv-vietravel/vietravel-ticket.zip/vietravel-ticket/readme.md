# Tài liệu hướng dẫn triển khai và sử dụng hệ thống phân tích vé VietJet

## 1. Yêu cầu hệ thống

- Đã cài đặt Docker và Docker Compose trên máy.
- Cổng 5100 (backend) và 3000 (frontend) chưa bị ứng dụng khác chiếm dụng.

## 2. Cấu trúc dự án

- `backend/`: Dịch vụ API .NET xử lý file vé.
- `frontend/`: Ứng dụng React giao diện người dùng.
- `docker-compose.yml`: Cấu hình chạy đồng thời cả hai dịch vụ.

## 3. Các bước triển khai

### 3.1. Chuẩn bị source code

- Copy toàn bộ mã nguồn về máy.
- Đảm bảo có đầy đủ các file Dockerfile trong `backend/` và `frontend/`.

### 3.2. Build và chạy hệ thống

Mở terminal tại thư mục gốc dự án, chạy lệnh:

```sh
docker-compose up --build
```

- Quá trình này sẽ tự động build và khởi động cả backend và frontend.

### 3.3. Kiểm tra dịch vụ

- Truy cập frontend tại: [http://localhost:3000](http://localhost:3000)
- Truy cập backend tại: [http://localhost:5100](http://localhost:5100)
- Kiểm tra API backend với Swagger: [http://localhost:5100/swagger](http://localhost:5100/swagger)

## 4. Sử dụng hệ thống

1. Truy cập giao diện web tại [http://localhost:3000](http://localhost:3000)
2. Chọn file vé máy bay VietJet định dạng `.docx`
3. Nhấn nút "Phân tích" để gửi file lên backend
4. Xem kết quả phân tích trả về trên giao diện

## 5. Phát triển và debug

- Backend: di chuyển vào thư mục `backend/`, chạy `dotnet run` để phát triển.
- Frontend: di chuyển vào thư mục `frontend/`, chạy `npm start` để phát triển.
- Khi thay đổi code, nên chạy lại `docker-compose up --build` để cập nhật container.

## 6. Lưu ý

- Nếu gặp lỗi port, kiểm tra lại các ứng dụng đang chạy trên máy.
- Đảm bảo file `.env` của frontend trỏ đúng địa chỉ backend nếu có thay đổi.
