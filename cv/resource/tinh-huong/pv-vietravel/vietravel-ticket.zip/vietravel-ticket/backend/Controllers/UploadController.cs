using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class UploadController : ControllerBase
{
    private readonly IDocxParser _parser;

    public UploadController(IDocxParser parser)
    {
        _parser = parser;
    }

    [HttpPost]
    public async Task<IActionResult> Upload(IFormFile file)
    {
        if (file == null || !file.FileName.EndsWith(".docx"))
            return BadRequest("Chỉ nhận file .docx");

        using var ms = new MemoryStream();
        await file.CopyToAsync(ms);
        ms.Position = 0;

        var ticket = _parser.Parse(ms);
        return Ok(ticket);
    }
}
