var builder = WebApplication.CreateBuilder(args);

 // Lắng nghe trên cổng 5100 của container
builder.WebHost.ConfigureKestrel(options =>
{
    options.ListenAnyIP(5100);
});

// Đăng ký controller
builder.Services.AddControllers();
// Thêm các dịch vụ vào container.
// Tìm hiểu thêm về cấu hình Swagger/OpenAPI tại https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
// Cấu hình CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend",
        policy => policy.WithOrigins("http://localhost:3000")
                        .AllowAnyHeader()
                        .AllowAnyMethod());
});

// Đăng ký parser
builder.Services.AddScoped<IDocxParser, DocxParser>();

var app = builder.Build();

// Cấu hình pipeline xử lý HTTP request.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// app.UseHttpsRedirection();
app.UseCors("AllowFrontend"); 
// Ánh xạ controller
app.MapControllers();

app.Run();