public class FlightDto
{
    public string FlightCode { get; set; } = string.Empty;
    public DateTime Date { get; set; }
    public string TicketClass { get; set; } = string.Empty;
    public string Departure { get; set; } = string.Empty;
    public string Arrival { get; set; } = string.Empty;
}