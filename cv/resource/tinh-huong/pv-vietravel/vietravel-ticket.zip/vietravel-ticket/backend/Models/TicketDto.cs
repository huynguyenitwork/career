public class TicketDto
{
    public string BookingCode { get; set; } = string.Empty;
    public DateTime? BookingDate { get; set; }
    public List<PassengerDto> Passengers { get; set; } = new();
    public List<FlightDto> Flights { get; set; } = new();
}