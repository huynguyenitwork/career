public interface IDocxParser
{
    TicketDto Parse(Stream docStream);
}