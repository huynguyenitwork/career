using System.Globalization;
using DocumentFormat.OpenXml.Packaging;
using System.Text.RegularExpressions;

public class DocxParser : IDocxParser
{

    public TicketDto Parse(Stream docStream)
    {
        var result = new TicketDto();

        using var wordDoc = WordprocessingDocument.Open(docStream, false);
        var body = wordDoc?.MainDocumentPart?.Document.Body;

        if (body == null)
            return result;

        // Giữ nguyên toàn bộ khoảng trắng (bao gồm xuống dòng, tab)
        var text = body.InnerText ?? string.Empty;
        if (string.IsNullOrEmpty(text))
            return result;

        // 1) Mã đặt chỗ
        var bookingRegex = new Regex(@"Mã\s*đặt\s*chỗ(?:\s*\(.*?\))?[:\-\s]*([A-Z0-9]{3,8})");
        var m = bookingRegex.Match(text);
        if (m.Success)
            result.BookingCode = m.Groups[1].Value.Trim();

        // 2) Ngày đặt vé
        var bookingDateRegex = new Regex(@"Ngày\s*đặt[:\-\s]*?(\d{1,2}/\d{1,2}/\d{4})");
        m = bookingDateRegex.Match(text);
        if (m.Success && DateTime.TryParse(m.Groups[1].Value, out var bdate))
            result.BookingDate = bdate;

        // 3) Phần thông tin hành khách
        var passengerSectionRegex = new Regex(@"2\.\s*Thông\s*tin\s*hành\s*khách(.*?)3\.", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        var passengerSectionMatch = passengerSectionRegex.Match(text);
        if (passengerSectionMatch.Success)
        {
            var passengerText = passengerSectionMatch.Groups[1].Value;
            // Loại bỏ tiêu đề như "Tên hành khách Số ghế" nếu có (giữ lại phần còn lại)
            passengerText = Regex.Replace(passengerText, @"Tên\s*hành\s*khách\s*Số\s*ghế", "", RegexOptions.IgnoreCase);

            // CHÍNH: tìm tên ngay trước mã VJ (lookahead)
            // Mẫu: các từ viết hoa có dấu phẩy (HỌ, TÊN ...) ngay trước VJ
            var nameRegex = new Regex(@"[A-Z][A-Z\s\.\-']+?,\s*[A-Z][A-Z\s\.\-']+(?=\s*VJ\d)", RegexOptions.Multiline);

            var nameMatches = nameRegex.Matches(passengerText).Cast<Match>().ToList();

            if (nameMatches.Count > 0)
            {
                for (int i = 0; i < nameMatches.Count; i++)
                {
                    var nm = nameMatches[i];
                    var name = nm.Value.Trim();
                    var parts = name.Split(',');

                    // Loại bỏ khoảng trắng
                    string firstName = parts[0].Trim();
                    string lastName = parts.Length > 1 ? parts[1].Trim() : "";

                    // flightBlock bắt đầu ngay sau tên và kết thúc ngay trước tên tiếp theo (hoặc hết)
                    var flightBlockStart = nm.Index + nm.Length;
                    var flightBlockEnd = (i + 1 < nameMatches.Count) ? nameMatches[i + 1].Index : passengerText.Length;
                    var flightBlockLen = Math.Max(0, flightBlockEnd - flightBlockStart);
                    var flightBlock = passengerText.Substring(flightBlockStart, flightBlockLen);

                    // lấy các mã VJ từ flightBlock
                    var codes = Regex.Matches(flightBlock, @"VJ\d{2,4}", RegexOptions.IgnoreCase)
                                     .Cast<Match>()
                                     .Select(x => x.Value.Trim())
                                     .Distinct()
                                     .ToList();

                    result.Passengers.Add(new PassengerDto
                    {
                        FirstName = firstName,
                        LastName = lastName,
                        FullName = $"{firstName} {lastName}",
                        FlightCodes = codes
                    });
                }
            }
        }

        // --- Phần chuyến bay: tách các block theo mã VJ và lấy thông tin (ngày, hạng vé, điểm đi/đến) ---
        var flightSectionRegex = new Regex(@"3\.\s*Thông\s*tin\s*chuyến\s*bay(.*)", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        var flightSectionMatch = flightSectionRegex.Match(text);
        if (flightSectionMatch.Success)
        {
            var flightText = flightSectionMatch.Groups[1].Value;

            // tìm tất cả các mã VJ và coi mỗi đoạn từ VJ này đến VJ tiếp theo là một chuyến bay
            var vjMatches = Regex.Matches(flightText, @"VJ\d{2,4}", RegexOptions.IgnoreCase).Cast<Match>().ToList();
            for (int i = 0; i < vjMatches.Count; i++)
            {
                var start = vjMatches[i].Index;
                var end = (i + 1 < vjMatches.Count) ? vjMatches[i + 1].Index : flightText.Length;
                var block = flightText.Substring(start, Math.Max(0, end - start));
                var flightCode = vjMatches[i].Value.Trim();

                // ngày bay
                var dateMatch = Regex.Match(block, @"(\d{1,2}/\d{1,2}/\d{4})");
                DateTime? flightDate = null;
                if (dateMatch.Success && DateTime.TryParseExact(dateMatch.Groups[1].Value,
                            ["d/M/yyyy", "dd/MM/yyyy"], CultureInfo.InvariantCulture, DateTimeStyles.None, out var fd))
                    flightDate = fd;

                // hạng vé
                var classMatch = Regex.Match(block, @"(Eco|Economy|Business|Promo|ECO|BUSINESS)", RegexOptions.IgnoreCase);
                var ticketClass = classMatch.Success ? classMatch.Groups[1].Value.Trim() : string.Empty;

                // điểm đi/đến (dự kiến có 2 cặp)
                var timeLocMatches = Regex.Matches(block,@"(\d{1,2}:\d{2})\s*-\s*([A-Za-z0-9\(\)\.\,\- ]+?(?:\([A-Z]{2,4}\))?)(?=\s*\d{1,2}:\d{2}|$)",RegexOptions.Singleline);

                string departure = string.Empty, arrival = string.Empty;

                if (timeLocMatches.Count >= 1)
                    departure = $"{timeLocMatches[0].Groups[1].Value} - {timeLocMatches[0].Groups[2].Value.Trim()}";

                if (timeLocMatches.Count >= 2)
                    arrival = $"{timeLocMatches[1].Groups[1].Value} - {timeLocMatches[1].Groups[2].Value.Trim()}";

                result.Flights.Add(new FlightDto
                {
                    FlightCode = flightCode,
                    Date = flightDate ?? DateTime.MinValue,
                    TicketClass = ticketClass,
                    Departure = departure,
                    Arrival = arrival
                });
            }
        }

        return result;
    }

    // helper: tìm indexOf không phân biệt hoa thường

}
