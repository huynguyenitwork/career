using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

public class UploadControllerTests
{
    [Fact]
    public async Task Upload_ReturnsTicket()
    {
        // Arrange
        var docxParserMock = new Mock<IDocxParser>();
        docxParserMock.Setup(x => x.Parse(It.IsAny<Stream>())).Returns(new TicketDto
        {
            Passengers = new List<PassengerDto> { new PassengerDto { FullName = "Nguyễn Văn A" } }
        });
        var controller = new UploadController(docxParserMock.Object);
        var fileMock = new FormFile(new MemoryStream(new byte[10]), 0, 10, "file", "test.docx");

        // Act
        var result = await controller.Upload(fileMock);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var ticket = Assert.IsType<TicketDto>(okResult.Value);
        Assert.NotEmpty(ticket.Passengers);
        Assert.Equal("Nguyễn Văn A", ticket.Passengers[0].FullName);
    }
}
